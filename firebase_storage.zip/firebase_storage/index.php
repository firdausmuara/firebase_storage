<?php

use Google\Cloud\Storage\StorageClient;
use Google\Auth\Credentials\ServiceAccountCredentials;
use Google\Auth\HttpHandler\HttpHandlerFactory;

require __DIR__.'/vendor/autoload.php';

use Kreait\Firebase\Factory;
use Kreait\Firebase\Storage;

class Firebase_engine
{
    static function factory()
    {
        $factory = (new Factory)
            ->withServiceAccount('datangg_firebase_admin.json')
            ->withProjectId("datangg");
                    
        return $factory;
    }

    static function getAccessToken()
    {
        $credential = new ServiceAccountCredentials(
            "https://www.googleapis.com/auth/firebase.storage",
            json_decode(file_get_contents(__DIR__ . '/datangg_firebase_admin.json'), true)
        );

        $accessToken = $credential->fetchAuthToken(HttpHandlerFactory::build());

        return $accessToken;
    }

    static function uploadFileToStorage($fileData, $fileNameEncoded)
    {
        // API Key atau Firebase ID Token untuk autentikasi (ganti dengan token yang sesuai)
        $accessToken = self::getAccessToken();
        // printr($accessToken);die;

        $firebaseStorageBucketUrl = 'https://firebasestorage.googleapis.com/v0/b/datangg.appspot.com/o/';
        // $firebaseStorageUrl = 'https://firebasestorage.googleapis.com/v0/b/staging-datangg.appspot.com/o/Profile%20Image/xJbOcJDm1EOAkQdj0P3Q/125819259_2799019546979252_3099556570327477479_n.jpeg?alt=media&token=10450a78-d240-4f88-bb47-e809f91937c6';

        // Firebase Storage object URL
        $uploadUrl = $firebaseStorageBucketUrl . $fileNameEncoded . '?uploadType=media';
        // printr($uploadUrl);die;

        // Set up the curl request
        $ch = curl_init();

        // Set the curl options
        curl_setopt($ch, CURLOPT_URL, $uploadUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $accessToken['access_token'],
            'Content-Type: application/octet-stream',
        ]);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fileData);

        // Execute the request and get the response
        $response = curl_exec($ch);

        // Check for errors
        if ($response === false) {
            $error = curl_error($ch);
            echo "cURL Error: " . $error;
        } else {
            // Successful response
            echo "File uploaded successfully: " . $response;
        }
    }
}

try {

    $firebase = new Firebase_engine();
    $accessToken = $firebase->getAccessToken();

    // Step 1: Initialize Firebase
    $factory = (new Factory)->withServiceAccount('datangg_firebase_admin.json');
    $storage = $factory->createStorage();

    // Step 2: Specify the file to upload
    $filePath = '/Applications/XAMPP/xamppfiles/htdocs/firebase_storage/pinjamanDaus.pdf'; // Path to the file you want to upload
    $bucket = $storage->getBucket('staging-datangg'); // Get the default storage bucket
    // print_r($bucket);
    // Step 3: Upload the file
    $object = $bucket->upload(
        fopen($filePath, 'r'), // Open the file for reading
        [
            'name' => 'penggajian/uploads/pinjaman/lampiran/file.pdf' // Specify the path in Firebase Storage
        ]
    );

    // Step 4: Output the public URL of the uploaded file
    $publicUrl = $object->signedUrl(new \DateTime('+1 hour')); // Generate a signed URL valid for 1 hour
    echo "File uploaded successfully. Access it at: " . $publicUrl;
    // print_r($accessToken);
} catch (\Throwable $th) {
    //throw $th;
}